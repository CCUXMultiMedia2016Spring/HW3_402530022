// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
angular.module('starter', ['ionic'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    if (window.cordova && window.cordova.plugins.Keyboard) {
      // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
      // for form inputs)
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);

      // Don't remove this line unless you know what you are doing. It stops the viewport
      // from snapping when text inputs are focused. Ionic handles this internally for
      // a much nicer keyboard experience.
      cordova.plugins.Keyboard.disableScroll(true);
    }
    if (window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
})

.controller('calCtrl', function($scope) {
  $scope.inp = '';
  $scope.cal = '';
  var inp = '';
  
  $scope.input = function(input) {
    if ($scope.ans == true) {
      console.log($scope.inp);
      $scope.inp = '';
    }
    $scope.ans = false;
    inp += input;
    console.log(input);
    if ($scope.sR == true) {
      $scope.inp = '(-' + inp + ')';
    } else {
      if ($scope.operate == true) {
        $scope.inp = input;
        $scope.operate = false;
      } else {
        $scope.inp += input;
      }

    }
  }
  $scope.operation = function(input) {
    inp = '';
    $scope.sR = false;
    if ($scope.operate != true) {
      if ($scope.inp != '') {
        $scope.cal += $scope.inp;
        console.log($scope.cal);
        $scope.cal += input;
        $scope.inp = input;
        console.log($scope.cal);
        $scope.operate = true;
      }
    } else {
      $scope.cal = $scope.cal.slice(0, -1);
      console.log($scope.cal);
      $scope.cal += input;
      console.log($scope.cal);
      $scope.inp = input;
      console.log($scope.cal);
      $scope.operate = true;
    }

  }
  $scope.Allclear = function() {
    console.log('All Clear');
    $scope.cal = '';
    $scope.inp = '';
    inp = '';
  }
  $scope.clear = function() {
    console.log('Clear');
    $scope.inp = '';
    inp = '';
  }
  $scope.calculate = function() {
    $scope.sR = false;
    $scope.cal += $scope.inp;
    console.log($scope.cal);
    $scope.cal = eval($scope.cal).toString();
    $scope.inp = $scope.cal;
    $scope.ans = true;
    $scope.cal = '';
  }
  $scope.sym = function() {
    if ($scope.operate == true) {
      $scope.inp = '';
      $scope.operate = false;
    }
    if ($scope.inp.indexOf('-') > -1) {
      $scope.inp = $scope.inp.replace("-", '');

    } else {
      if ($scope.inp == '') {
        $scope.sR = true;
      } else {
        $scope.inp = '(-' + $scope.inp + ')';
      }

    }
  }
})
